
 integer :: a,b
 common/block_1/a,b

